﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KomljenovicVladoRichTextBox
{
    public partial class btnCitaj : Form
    {
        public btnCitaj()
        {
            InitializeComponent();
        }

        private void btnSpremi_Click(object sender, EventArgs e)
        {
            richTextBox.SaveFile(@"C:TempProba.rtf");
            MessageBox.Show("Tekst spremljen");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox.LoadFile(@"TempProba.rtf");
        }

        private void btnBrisi_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();

        }
    }
}
