﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KomljenovicVladoKlaseiObjekti1.Klasa;

namespace KomljenovicVladoKlaseiObjekti1
{
    class Program
    {
        static void Main(string[] args)
        {
            Vozilo avion = new Vozilo();
            avion.setBrojKotaca( 6 );
            avion.setLeti(  true );
            avion.setPliva( false );
            avion.setVozi( true );
            avion.setVrsta( " Cessna " );
            avion.setOznaka( " 1312 " );

            Console.WriteLine("\nVrsta: " + avion.getVrsta()  +  "\nOznaka: " + avion.getOznaka() +
                "\nLeti" + avion.getLeti() 
                + "\nPliva" + avion.getPliva() + "\nVozi" + avion.getVozi() + "\nBroj kotaca: " + avion.getBrojKotaca());

           

            Vozilo kamion = new Vozilo(8,false,false,true,"TAM","RI1987RI");

            Console.WriteLine(kamion.ToString());
            Console.WriteLine(avion.ToString());
           
            Console.ReadLine();

        }
    }
}
