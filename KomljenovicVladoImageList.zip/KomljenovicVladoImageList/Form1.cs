﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KomljenovicVladoImageList
{
    public partial class FormImageList : Form
    {
        public int brojac = 1;
        public FormImageList()
        {
            InitializeComponent();
            pictureBox1.Image = imageList1.Images[0];

        }
       

        private void button1_Click(object sender, EventArgs e)
        {
   if (brojac % 2 == 0)
        pictureBox1.Image = imageList1.Images[0];
    else
        pictureBox1.Image = imageList1.Images[1];
    brojac++;
        }

        private void oProgramuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Naziv programa: ImageList\n Ime učenika: Vlado  \n Prezime učenika: Komljenovic \n" +
            " Datum izrade 22.1.2019 \nDavatelj licence dopušta umnožavanje, distribuiranje i priopćavanje djela javnosti." +
            " Zauzvrat primatelji licence moraju imenovanjem priznati i označiti izvornog autora.");
        }
    }
    }

