﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KomljenovicVladoPictureBoxKontrola
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;

        }

        private void oProgramuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Naziv programa: ImageBox\n Ime učenika: Vlado  \n Prezime učenika: Komljenovic \n" +
           " Datum izrade 22.1.2019 \nDavatelj licence dopušta umnožavanje, distribuiranje i priopćavanje djela javnosti." +
           " Zauzvrat primatelji licence moraju imenovanjem priznati i označiti izvornog autora.");
        }
    }
}
