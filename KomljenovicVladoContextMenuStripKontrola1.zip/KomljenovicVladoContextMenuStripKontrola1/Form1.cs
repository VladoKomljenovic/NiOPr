﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KomljenovicVladoContextMenuStripKontrola1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LijevodesnoToolStripMenuItem_Click(object sender, CancelEventArgs e)
        {
            textBoxlijevo.Text = textBoxdesno.Text;
        }
        
        private void desnoLijevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBoxdesno.Text =textBoxlijevo.Text;
        }

       
    }
}

